#!/bin/bash
rm -rf *.in *.out
